जन जन की आवाज़ NEWS — Admin Panel Starter

ADMIN URL:
https://janjankiawajnews.netlify.app/admin/

इस पैकेज में Decap CMS का Admin interface और समाचार लिखने का फॉर्म है।
यह अभी आपके Netlify अकाउंट या GitHub repository से कनेक्ट नहीं हुआ है।

जरूरी बातें:
- Decap CMS खबरें Git repository में Markdown files के रूप में सेव करता है।
- इस समय आपकी पुरानी static homepage उन Markdown खबरों को अपने आप वेबसाइट पर नहीं दिखाती। Public news listing के लिए frontend को content से जोड़ने वाला build step भी करना होगा।
- Netlify Git Gateway deprecated है; इस पैकेज में GitHub backend रखा गया है।

सेटअप:
1. अभिभावक/साइट मालिक की मदद से GitHub repository बनाएं।
2. इस ZIP की सभी files repository के root में डालें।
3. admin/config.yml में YOUR_GITHUB_USERNAME/YOUR_REPOSITORY को अपने असली GitHub owner/repository से बदलें।
4. Netlify में मौजूदा site को उसी GitHub repository की main branch से connect करें।
5. GitHub OAuth authentication provider को Netlify में configure करें। Decap CMS के आधिकारिक GitHub backend दस्तावेज़ में Netlify authentication setup दिया है:
   https://decapcms.org/docs/github-backend/
6. Deploy पूरा होने के बाद https://janjankiawajnews.netlify.app/admin/ खोलें और GitHub से login करें। केवल भरोसेमंद संपादकों को repository write access दें।

सुरक्षा:
- GitHub password, OAuth client secret या access token किसी से साझा न करें और HTML/config.yml में न डालें।
- Public signup बंद रखें; केवल भरोसेमंद संपादकों को अनुमति दें।
- अभिभावक/साइट मालिक से अकाउंट सेटअप और permissions की निगरानी करवाएं।

जब account/repository की जानकारी और authentication तैयार हो जाए, तब frontend news listing जोड़कर Publish की गई खबरें homepage पर दिखाने का अगला काम किया जा सकता है।
